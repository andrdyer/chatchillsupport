// Token service for Agora RTC and Chat tokens

import { RtcTokenBuilder, Role } from "./token-builder"

// Constants
const APP_ID = process.env.NEXT_PUBLIC_AGORA_APP_ID || ""
const APP_CERTIFICATE = process.env.AGORA_APP_CERTIFICATE || ""
const CHAT_APP_KEY = "411335512#1539074" // Your Agora Chat App Key

// Token expiration times (in seconds)
const RTC_TOKEN_EXPIRATION = 3600 // 1 hour
const PRIVILEGE_EXPIRATION = 3600 // 1 hour

/**
 * Generate an RTC token for video/audio communication
 */
export const generateRtcToken = (channelName: string, uid: number): string => {
  if (!APP_ID || !APP_CERTIFICATE) {
    console.error("Missing Agora credentials - APP_ID or APP_CERTIFICATE not set")
    throw new Error("Agora credentials not configured")
  }

  try {
    // Generate the token using the RtcTokenBuilder
    const token = RtcTokenBuilder.buildTokenWithUid(
      APP_ID,
      APP_CERTIFICATE,
      channelName,
      uid,
      Role.PUBLISHER,
      Math.floor(Date.now() / 1000) + RTC_TOKEN_EXPIRATION,
      Math.floor(Date.now() / 1000) + PRIVILEGE_EXPIRATION,
    )

    return token
  } catch (error) {
    console.error("Error generating RTC token:", error)
    throw error
  }
}

/**
 * Generate a simple token for testing purposes
 * This is useful when you don't have the APP_CERTIFICATE
 */
export const generateSimpleToken = (channelName: string, uid: number): string => {
  // Create a simple token format that includes the channel name and uid
  // This is NOT secure and should only be used for testing
  const timestamp = Date.now()
  const simpleToken = Buffer.from(`${APP_ID}:${channelName}:${uid}:${timestamp}`).toString("base64")
  return simpleToken
}

/**
 * Check if Agora credentials are properly configured
 */
export const checkAgoraCredentials = (): boolean => {
  if (!APP_ID) {
    console.error("Missing NEXT_PUBLIC_AGORA_APP_ID environment variable")
    return false
  }

  if (!APP_CERTIFICATE) {
    console.error("Missing AGORA_APP_CERTIFICATE environment variable")
    return false
  }

  return true
}
